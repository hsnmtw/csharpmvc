﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ModelLibrary.Security;

namespace ViewWinform.Security.Entitlements
{
    public partial class EntitlementsTabView : UserControl
    {
        public EntitlementsTabView()
        {
            InitializeComponent();
        }


        private void Button1_Click(object sender, EventArgs e)
        {

        }
    }
}
