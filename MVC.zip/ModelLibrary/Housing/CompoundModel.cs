﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ModelLibrary.Common;

namespace ModelLibrary.Housing
{
    public class CompoundModel : BaseModel
    {
        public String Compound_Name { get; set; }
    }
}
